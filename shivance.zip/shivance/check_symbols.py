import requests
import json
from datetime import datetime

def load_access_token():
    try:
        with open("access_token.txt", "r") as f:
            return f.read().strip()
    except Exception as e:
        print(f"Error loading access token: {e}")
        return None

ACCESS_TOKEN = load_access_token()

def get_valid_futures():
    if not ACCESS_TOKEN:
        print("No valid access token. Please run get_token.py.")
        return
    
    try:
        # Attempt to fetch BOD instruments JSON
        bod_url = "https://api.upstox.com/v2/instruments"
        headers = {
            "Authorization": f"Bearer {ACCESS_TOKEN}",
            "Accept": "application/json",
            "Api-Version": "2.0"
        }
        response = requests.get(bod_url, headers=headers)
        
        if response.status_code == 200:
            instruments = response.json().get("data", [])
            futures = [
                inst["instrument_key"]
                for inst in instruments
                if inst["exchange"] == "NSE_FO"
                and inst["instrument_type"] == "FUT"
                and ("NIFTY" in inst["trading_symbol"] or "BANKNIFTY" in inst["trading_symbol"])
                and "FUT" in inst["trading_symbol"]
            ]
            if futures:
                print("Valid futures symbols:", futures)
            else:
                print("No NIFTY or BANKNIFTY futures found.")
        else:
            print(f"Failed to fetch BOD instruments: {response.status_code} - {response.text}")
            # Fallback: Static mapping for July 2025 futures (adjust based on current month)
            current_month = datetime.now().strftime("%y%b").upper()  # e.g., "25JUL"
            next_month = (datetime.now().replace(day=1) + timedelta(days=32)).strftime("%y%b").upper()  # e.g., "25AUG"
            fallback_futures = [
                f"NSE_FO|NIFTY{next_month}FUT",
                f"NSE_FO|BANKNIFTY{next_month}FUT"
            ]
            print("Using fallback futures symbols (verify with Upstox):", fallback_futures)
            
    except Exception as e:
        print(f"Error fetching instruments: {e}")
        # Fallback: Static mapping
        current_month = datetime.now().strftime("%y%b").upper()
        next_month = (datetime.now().replace(day=1) + timedelta(days=32)).strftime("%y%b").upper()
        fallback_futures = [
            f"NSE_FO|NIFTY{next_month}FUT",
            f"NSE_FO|BANKNIFTY{next_month}FUT"
        ]
        print("Using fallback futures symbols (verify with Upstox):", fallback_futures)

if __name__ == "__main__":
    get_valid_futures()
