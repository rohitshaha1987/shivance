import http.server
import socketserver
import webbrowser
import urllib.parse
import requests
import time

PORT = 8000
client_id = "a1b11a00-041d-418e-9887-d6696b016620"
client_secret = "vbtbiyziuu"
redirect_uri = "http://127.0.0.1:8000"

class AuthHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(b"Done! Close this window.")
        query = urllib.parse.urlparse(self.path).query
        query_components = urllib.parse.parse_qs(query)
        code = query_components.get("code", [None])[0]
        if code:
            try:
                response = requests.post(
                    "https://api.upstox.com/v2/login/authorization/token",
                    headers={"accept": "application/json", "Content-Type": "application/x-www-form-urlencoded"},
                    data={
                        "code": code,
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "redirect_uri": redirect_uri,
                        "grant_type": "authorization_code"
                    }
                )
                if response.status_code == 200:
                    token = response.json().get("access_token")
                    print("Access Token:", token)
                    with open("access_token.txt", "w") as f:
                        f.write(token)
                else:
                    print("Error getting token:", response.json())
            except Exception as e:
                print("Error:", e)
        else:
            print("No code received")
        self.server.shutdown()

Handler = AuthHandler
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print("Browser opened. Enter mobile number, OTP, and PIN.")
    webbrowser.open(f"https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id={client_id}&redirect_uri={redirect_uri}")
    httpd.serve_forever()
