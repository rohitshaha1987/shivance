import upstox_client
from upstox_client.rest import ApiException
import pandas as pd
import numpy as np
import logging
from datetime import datetime
import time
import json

# Configure logging
logging.basicConfig(
    filename=f"logs/trade_log_{datetime.now().strftime('%Y%m%d')}.log",
    level=logging.INFO,
    format="%(asctime)s:%(levelname)s:%(message)s"
)

# Upstox API configuration
API_KEY = "a1b11a00-041d-418e-9887-d6696b016620"  # Replace with your API key
SANDBOX_MODE = True  # Set to False for live trading

def get_access_token():
    """Load and validate access token from file."""
    try:
        with open("access_token.txt", "r") as f:
            token = f.read().strip()
            if not token:
                logging.error("Access token is empty.")
                return None
            return token
    except FileNotFoundError:
        logging.error("access_token.txt not found.")
        return None
    except Exception as e:
        logging.error(f"Error loading access token: {e}")
        return None

def initialize_upstox_api():
    """Initialize Upstox API client with token validation."""
    access_token = get_access_token()
    if not access_token:
        logging.error("No valid access token. Cannot initialize API client.")
        return None
    configuration = upstox_client.Configuration()
    configuration.access_token = access_token
    configuration.sandbox = SANDBOX_MODE
    return upstox_client.ApiClient(configuration)

def calculate_indicators(df, identifier):
    """Calculate technical indicators for ML strategy."""
    try:
        if df is None or df.empty or 'close' not in df.columns:
            logging.warning(f"No valid data for {identifier}. Columns: {df.columns.tolist() if df is not None else 'None'}")
            return pd.DataFrame()
        df = df.sort_index()
        delta = df['close'].diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        df['RSI'] = 100 - (100 / (1 + rs))
        ema12 = df['close'].ewm(span=12, adjust=False).mean()
        ema26 = df['close'].ewm(span=26, adjust=False).mean()
        df['MACD'] = ema12 - ema26
        df['MACD_Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
        df['Volume_Ratio'] = df['volume'] / df['volume'].rolling(window=20).mean()
        # Calculate ATR
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        df['ATR'] = tr.rolling(window=14).mean()
        # Calculate VWAP
        typical_price = (df['high'] + df['low'] + df['close']) / 3
        df['VWAP'] = (typical_price * df['volume']).cumsum() / df['volume'].cumsum()
        # Calculate additional features
        df['Price_Change'] = df['close'].pct_change() * 100
        df['Price_Change_2'] = df['close'].pct_change(periods=2) * 100
        df['Price_Change_5'] = df['close'].pct_change(periods=5) * 100
        df['Price_Volume_Corr'] = df['close'].rolling(window=20).corr(df['volume'])
        df['Fake_Volume_Flag'] = (df['volume'] / df['volume'].rolling(window=20).mean() > 2).astype(int)
        logging.info(f"Indicators calculated for {identifier}: {len(df)} rows")
        return df.rename(columns={"open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume"})
    except Exception as e:
        logging.error(f"Error calculating indicators for {identifier}: {e}")
        return pd.DataFrame()

def get_data(symbol, period="1y", interval="1d"):
    """Fetch historical data using Upstox Historical API with enhanced error handling."""
    try:
        api_client = initialize_upstox_api()
        if not api_client:
            logging.error(f"Failed to initialize API client for {symbol}")
            return pd.DataFrame()
        history_api = upstox_client.HistoricalApi(api_client)
        # Map periods and intervals to Upstox API format
        interval_map = {
            "5m": "5minute",
            "15m": "15minute",
            "1h": "1hour",
            "1d": "1day"
        }
        period_map = {
            "1y": (datetime.now() - pd.Timedelta(days=365)).strftime("%Y-%m-%d"),
            "6mo": (datetime.now() - pd.Timedelta(days=180)).strftime("%Y-%m-%d"),
            "3mo": (datetime.now() - pd.Timedelta(days=90)).strftime("%Y-%m-%d"),
            "1mo": (datetime.now() - pd.Timedelta(days=30)).strftime("%Y-%m-%d"),
            "5d": (datetime.now() - pd.Timedelta(days=5)).strftime("%Y-%m-%d")
        }
        api_interval = interval_map.get(interval, "1day")
        from_date = period_map.get(period, period_map["1y"])
        to_date = datetime.now().strftime("%Y-%m-%d")
        logging.info(f"Fetching historical data for {symbol} with interval={api_interval}, from={from_date}, to={to_date}")
        response = history_api.get_historical_candle(symbol, api_interval, to_date, from_date)
        if response.status != "success" or not response.data.candles:
            logging.warning(f"No historical data for {symbol}. Response: {response}")
            # Try fallback periods
            for fallback_period in ["1mo", "5d"]:
                from_date = period_map.get(fallback_period)
                logging.info(f"Trying fallback period {fallback_period} for {symbol}")
                response = history_api.get_historical_candle(symbol, api_interval, to_date, from_date)
                if response.status == "success" and response.data.candles:
                    logging.info(f"Retrieved data for {symbol} with fallback period={fallback_period}")
                    break
            else:
                logging.warning(f"All periods failed for {symbol}")
                return pd.DataFrame()
        # Convert candles to DataFrame
        candles = response.data.candles
        df = pd.DataFrame(candles, columns=["timestamp", "open", "high", "low", "close", "volume", "oi"])
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df.set_index("timestamp", inplace=True)
        df = df[["open", "high", "low", "close", "volume"]]
        if len(df) < 5:  # Relaxed constraint for testing
            logging.warning(f"Insufficient historical data for {symbol}: {len(df)} rows")
            return pd.DataFrame()
        logging.info(f"Retrieved {len(df)} rows for {symbol}")
        return df
    except ApiException as e:
        logging.error(f"Upstox API error fetching historical data for {symbol}: {e}")
        return pd.DataFrame()
    except Exception as e:
        logging.error(f"Error fetching historical data for {symbol}: {e}")
        return pd.DataFrame()

def get_current_price(symbol):
    """Fetch current price using Upstox MarketDataStreamerV3."""
    try:
        api_client = initialize_upstox_api()
        if not api_client:
            logging.error(f"Failed to initialize API client for {symbol}")
            return 0.0
        logging.info(f"Fetching current price for {symbol}")
        price_data = {"ltp": 0.0}

        def on_message(message):
            data = json.loads(message)
            if "feeds" in data and symbol in data["feeds"]:
                price_data["ltp"] = data["feeds"][symbol]["ltpc"]["ltp"]
            streamer.disconnect()

        def on_error(message):
            logging.error(f"WebSocket error for {symbol}: {message}")

        def on_open():
            streamer.subscribe([symbol], "ltpc")

        streamer = upstox_client.MarketDataStreamerV3(api_client, [symbol], "ltpc")
        streamer.on("open", on_open)
        streamer.on("message", on_message)
        streamer.on("error", on_error)
        streamer.connect()
        time.sleep(3)  # Increased wait time for data
        price = price_data["ltp"]
        if price <= 0:
            logging.warning(f"No valid current price for {symbol}")
            return 0.0
        logging.info(f"Fetched current price for {symbol}: ₹{price}")
        return price
    except Exception as e:
        logging.error(f"Error fetching current price for {symbol}: {e}")
        return 0.0
