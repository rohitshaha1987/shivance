import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import threading
import logging
import json
import gzip
from datetime import datetime
from strategy import AdvancedScalpingBotStrategy

class TradingBotUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Scalping Bot - Upstox API")
        self.root.geometry("1200x800")
        self.is_running = False
        self.is_backtesting = False
        self.strategy = AdvancedScalpingBotStrategy(self)
        logging.basicConfig(
            filename=f"logs/trade_log_{datetime.now().strftime('%Y%m%d')}.log",
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )
        self.create_widgets()
        self.validate_initial_symbols()
        self.update_positions_display()
        self.update_history_display()
        self.update_market_data_display()

    def create_widgets(self):
        """Create UI widgets with improved layout."""
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # Status and metrics
        self.status_label = ttk.Label(self.main_frame, text="Status: Idle")
        self.status_label.grid(row=0, column=0, columnspan=5, sticky=tk.W)
        
        self.balance_label = ttk.Label(self.main_frame, text=f"Balance: ₹{self.strategy.balance:,.2f}")
        self.balance_label.grid(row=1, column=0, sticky=tk.W)
        
        self.daily_trades_label = ttk.Label(self.main_frame, text="Daily Trades: 0")
        self.daily_trades_label.grid(row=1, column=1, sticky=tk.W)
        
        self.drawdown_label = ttk.Label(self.main_frame, text=f"Max Drawdown: ₹{self.strategy.max_drawdown:,.2f}")
        self.drawdown_label.grid(row=1, column=2, sticky=tk.W)
        
        self.exposure_label = ttk.Label(self.main_frame, text="Total Exposure: ₹0.00")
        self.exposure_label.grid(row=2, column=0, sticky=tk.W)
        
        # Control buttons
        ttk.Button(self.main_frame, text="START STUDY", command=self.start_study).grid(row=3, column=0, pady=5)
        ttk.Button(self.main_frame, text="START SCALPING", command=self.start_scalping).grid(row=3, column=1, pady=5)
        ttk.Button(self.main_frame, text="STOP", command=self.stop_bot).grid(row=3, column=2, pady=5)
        ttk.Button(self.main_frame, text="START BACKTEST", command=self.start_backtest).grid(row=3, column=3, pady=5)
        ttk.Button(self.main_frame, text="CONVERT INSTRUMENTS", command=self.convert_instruments).grid(row=3, column=4, pady=5)
        ttk.Button(self.main_frame, text="ADD SCRIPT", command=self.add_script).grid(row=4, column=0, pady=5)
        ttk.Button(self.main_frame, text="REMOVE SCRIPT", command=self.remove_script).grid(row=4, column=1, pady=5)
        ttk.Button(self.main_frame, text="VALIDATE SYMBOLS", command=self.validate_initial_symbols).grid(row=4, column=2, pady=5)
        
        # Progress bar
        self.progress = ttk.Progressbar(self.main_frame, length=400, mode='determinate')
        self.progress.grid(row=5, column=0, columnspan=5, pady=5)
        
        # Asset checkboxes
        self.asset_frame = ttk.LabelFrame(self.main_frame, text="Assets")
        self.asset_frame.grid(row=6, column=0, columnspan=5, pady=5, sticky=tk.W)
        self.asset_vars = {}
        self.update_asset_checkboxes()
        
        # Market data display
        self.market_frame = ttk.LabelFrame(self.main_frame, text="Market Data")
        self.market_frame.grid(row=7, column=0, columnspan=5, pady=5, sticky=(tk.W, tk.E))
        
        self.market_tree = ttk.Treeview(self.market_frame, columns=(
            "Asset", "Price", "Change %", "Signal", "Confidence", "Volume", "ATR", "VWAP"
        ), show="headings")
        
        self.market_tree.heading("Asset", text="Asset")
        self.market_tree.heading("Price", text="Price")
        self.market_tree.heading("Change %", text="Change %")
        self.market_tree.heading("Signal", text="Signal")
        self.market_tree.heading("Confidence", text="Confidence")
        self.market_tree.heading("Volume", text="Volume")
        self.market_tree.heading("ATR", text="ATR")
        self.market_tree.heading("VWAP", text="VWAP")
        
        self.market_tree.column("Asset", width=200)
        self.market_tree.column("Price", width=100)
        self.market_tree.column("Change %", width=80)
        self.market_tree.column("Signal", width=80)
        self.market_tree.column("Confidence", width=100)
        self.market_tree.column("Volume", width=100)
        self.market_tree.column("ATR", width=80)
        self.market_tree.column("VWAP", width=100)
        
        self.market_tree.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # Open positions display
        self.positions_frame = ttk.LabelFrame(self.main_frame, text="Open Positions")
        self.positions_frame.grid(row=8, column=0, columnspan=5, pady=5, sticky=(tk.W, tk.E))
        
        self.positions_tree = ttk.Treeview(self.positions_frame, columns=(
            "Asset", "Quantity", "Buy Price", "Current Price", "P&L", "P&L %", "Buy Time", "Trailing Stop"
        ), show="headings")
        
        self.positions_tree.heading("Asset", text="Asset")
        self.positions_tree.heading("Quantity", text="Quantity")
        self.positions_tree.heading("Buy Price", text="Buy Price")
        self.positions_tree.heading("Current Price", text="Current Price")
        self.positions_tree.heading("P&L", text="P&L")
        self.positions_tree.heading("P&L %", text="P&L %")
        self.positions_tree.heading("Buy Time", text="Buy Time")
        self.positions_tree.heading("Trailing Stop", text="Trailing Stop")
        
        self.positions_tree.column("Asset", width=200)
        self.positions_tree.column("Quantity", width=80)
        self.positions_tree.column("Buy Price", width=100)
        self.positions_tree.column("Current Price", width=100)
        self.positions_tree.column("P&L", width=100)
        self.positions_tree.column("P&L %", width=80)
        self.positions_tree.column("Buy Time", width=100)
        self.positions_tree.column("Trailing Stop", width=100)
        
        self.positions_tree.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # Trade history display
        self.history_frame = ttk.LabelFrame(self.main_frame, text="Trade History")
        self.history_frame.grid(row=9, column=0, columnspan=5, pady=5, sticky=(tk.W, tk.E))
        
        self.history_tree = ttk.Treeview(self.history_frame, columns=(
            "Time", "Asset", "Action", "Quantity", "Price", "P&L", "Balance"
        ), show="headings")
        
        self.history_tree.heading("Time", text="Time")
        self.history_tree.heading("Asset", text="Asset")
        self.history_tree.heading("Action", text="Action")
        self.history_tree.heading("Quantity", text="Quantity")
        self.history_tree.heading("Price", text="Price")
        self.history_tree.heading("P&L", text="P&L")
        self.history_tree.heading("Balance", text="Balance")
        
        self.history_tree.column("Time", width=150)
        self.history_tree.column("Asset", width=200)
        self.history_tree.column("Action", width=80)
        self.history_tree.column("Quantity", width=80)
        self.history_tree.column("Price", width=100)
        self.history_tree.column("P&L", width=100)
        self.history_tree.column("Balance", width=100)
        
        self.history_tree.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # Log display
        self.log_frame = ttk.LabelFrame(self.main_frame, text="Log")
        self.log_frame.grid(row=10, column=0, columnspan=5, pady=5, sticky=(tk.W, tk.E))
        
        self.log_text = tk.Text(self.log_frame, height=8, width=100)
        self.log_text.grid(row=0, column=0)
        
        self.log_scroll = ttk.Scrollbar(self.log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.log_text.config(yscrollcommand=self.log_scroll.set)

    def convert_instruments(self):
        """Convert complete.json.gz to instruments.json with Nifty 50 and Nifty options."""
        input_file = "C:/Users/shaha/Desktop/shivance/complete.json.gz"
        output_file = "C:/Users/shaha/Desktop/shivance/instruments.json"
        
        try:
            # Read and decompress the .gz file
            with gzip.open(input_file, 'rb') as f:
                json_bytes = f.read()
                json_string = json_bytes.decode('utf-8')
                
                # Parse JSON Lines, handle incomplete entries
                instruments = []
                current_timestamp = int(datetime.now().timestamp() * 1000)  # Current time in milliseconds
                for line in json_string.splitlines():
                    try:
                        instr = json.loads(line)
                        # Ensure instr is a dictionary
                        if not isinstance(instr, dict):
                            logging.warning(f"Skipping non-dictionary JSON entry: {line}")
                            continue
                        # Filter for Nifty 50, Nifty options, or specific instrument
                        instrument_key = instr.get('instrument_key')
                        if not instrument_key:
                            logging.warning(f"Skipping entry without instrument_key: {line}")
                            continue
                        if (instrument_key == 'NSE_INDEX|Nifty 50' or
                            instrument_key == 'NSE_FO|36365' or
                            (instr.get('segment') == 'NSE_FO' and instr.get('underlying_key') == 'NSE_INDEX|Nifty 50')):
                            # Check for expired instruments
                            expiry = instr.get('expiry', float('inf'))
                            if expiry < current_timestamp:
                                logging.warning(f"Skipping expired instrument: {instrument_key} (Expiry: {datetime.fromtimestamp(expiry/1000).strftime('%Y-%m-%d')})")
                                continue
                            if instrument_key not in instruments:  # Avoid duplicates
                                instruments.append(instrument_key)
                    except json.JSONDecodeError:
                        logging.warning(f"Skipping invalid JSON line: {line}")
                        continue
            
            # Ensure Nifty 50 is included
            if 'NSE_INDEX|Nifty 50' not in instruments:
                instruments.insert(0, 'NSE_INDEX|Nifty 50')
                logging.info("Added Nifty 50 to instruments list")
            
            # Save to instruments.json (list of instrument keys)
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(instruments, f, indent=4)
            
            # Update config and UI
            self.strategy.config["assets"] = instruments
            self.update_asset_checkboxes()
            self.update_market_data_display()  # Refresh market data display
            self.show_alert("Success", f"Converted {len(instruments)} instruments to {output_file}")
            logging.info(f"Converted {len(instruments)} instruments to {output_file}")
        except FileNotFoundError:
            self.show_alert("Error", f"File not found at {input_file}")
            logging.error(f"File not found: {input_file}")
        except Exception as e:
            self.show_alert("Error", f"Error converting instruments: {e}")
            logging.error(f"Error converting instruments: {e}")

    def validate_initial_symbols(self):
        """Validate symbols in instruments.json at startup."""
        invalid_symbols = []
        for symbol in self.strategy.config["assets"]:
            if not self.strategy.validate_symbol(symbol):
                invalid_symbols.append(symbol)
                self.strategy.active_assets[symbol] = False
        if invalid_symbols:
            self.show_alert(
                "Symbol Validation Warning",
                f"Invalid symbols detected: {', '.join(invalid_symbols)}. "
                "They have been deactivated. Please update to valid Upstox instrument keys (e.g., NSE_FO|NIFTY25AUGFUT) via ADD SCRIPT."
            )
            logging.warning(f"Invalid symbols at startup: {invalid_symbols}")

    def update_asset_checkboxes(self):
        """Update asset checkboxes based on instruments.json."""
        for widget in self.asset_frame.winfo_children():
            widget.destroy()
        self.asset_vars = {}
        for i, asset in enumerate(self.strategy.config["assets"]):
            var = tk.BooleanVar(value=self.strategy.active_assets.get(asset, True))
            self.asset_vars[asset] = var
            ttk.Checkbutton(self.asset_frame, text=asset, variable=var,
                           command=lambda a=asset: self.toggle_asset(a)).grid(row=i//3, column=i%3, sticky=tk.W)

    def add_script(self):
        """Add a new Upstox instrument key and validate it."""
        symbol = simpledialog.askstring("Add Script", "Enter Upstox symbol (e.g., NSE_FO|NIFTY25JULFUT):")
        if symbol and symbol not in self.strategy.config["assets"]:
            if self.strategy.validate_symbol(symbol):
                self.strategy.config["assets"].append(symbol)
                self.strategy.active_assets[symbol] = True
                with open("C:/Users/shaha/Desktop/shivance/instruments.json", "w") as f:
                    json.dump(self.strategy.config["assets"], f, indent=4)
                self.update_asset_checkboxes()
                self.show_alert("Success", f"Added {symbol}")
                logging.info(f"Added script: {symbol}")
            else:
                self.show_alert(
                    "Error",
                    f"Invalid symbol: {symbol}. Ensure it matches Upstox format (e.g., NSE_FO|NIFTY25AUGFUT) and check API connectivity."
                )
                logging.error(f"Failed to add invalid symbol: {symbol}")
        elif symbol:
            self.show_alert("Error", f"Symbol {symbol} already exists.")
            logging.warning(f"Attempted to add duplicate symbol: {symbol}")

    def remove_script(self):
        """Remove a selected script from the asset list."""
        selected = self.market_tree.selection()
        if selected:
            symbol = self.market_tree.item(selected[0])["values"][0]
            if symbol in self.strategy.config["assets"]:
                self.strategy.config["assets"].remove(symbol)
                self.strategy.active_assets.pop(symbol, None)
                with open("C:/Users/shaha/Desktop/shivance/instruments.json", "w") as f:
                    json.dump(self.strategy.config["assets"], f, indent=4)
                self.update_asset_checkboxes()
                self.show_alert("Success", f"Removed {symbol}")
                logging.info(f"Removed script: {symbol}")
            else:
                self.show_alert("Error", f"Symbol {symbol} not found in assets")
                logging.error(f"Failed to remove symbol: {symbol}")
        else:
            self.show_alert("Error", "No symbol selected for removal")
            logging.warning("Remove script attempted with no selection")

    def update_log(self):
        """Update log display with latest log file contents."""
        try:
            with open(f"logs/trade_log_{datetime.now().strftime('%Y%m%d')}.log", "r") as f:
                lines = f.readlines()
                self.log_text.delete(1.0, tk.END)
                self.log_text.insert(tk.END, "".join(lines[-30:]))
                self.log_text.see(tk.END)
                for line in lines[-10:]:
                    if "ApiException" in line or "Unauthorized" in line:
                        self.show_alert(
                            "API Error",
                            "Upstox API error detected (e.g., invalid token). Regenerate access token in Upstox Developer Console."
                        )
                        break
                    if "WebSocket error" in line:
                        self.show_alert(
                            "WebSocket Error",
                            "Failed to fetch real-time data. Check network or Upstox API status."
                        )
                        break
                    if "No data" in line or "Insufficient" in line:
                        self.show_alert(
                            "Data Warning",
                            "No or insufficient data received from Upstox API. Check symbol validity or API subscription."
                        )
                        break
        except FileNotFoundError:
            self.log_text.delete(1.0, tk.END)
            self.log_text.insert(tk.END, "No logs available.")
        except Exception as e:
            self.log_text.delete(1.0, tk.END)
            self.log_text.insert(tk.END, f"Error reading log: {e}")
        self.root.after(2000, self.update_log)

    def toggle_asset(self, asset):
        """Toggle asset activation status."""
        self.strategy.active_assets[asset] = self.asset_vars[asset].get()
        logging.info(f"Asset {asset} {'activated' if self.strategy.active_assets[asset] else 'deactivated'}")
        self.update_market_data_display()

    def update_status(self, status):
        """Update status label."""
        self.status_label.config(text=f"Status: {status}")

    def update_progress(self, value):
        """Update progress bar."""
        self.progress['value'] = value
        self.root.update_idletasks()

    def show_alert(self, title, message):
        """Show alert message."""
        messagebox.showinfo(title, message)

    def start_study(self):
        """Start ML model training."""
        if not self.is_running:
            self.is_running = True
            self.update_status("Starting ML Study...")
            threading.Thread(target=self.strategy.train_ml_model, daemon=True).start()

    def start_scalping(self):
        """Start scalping thread."""
        if not self.is_running:
            self.is_running = True
            self.update_status("Starting Scalping...")
            threading.Thread(target=self.strategy.scalping_thread, daemon=True).start()

    def start_backtest(self):
        """Start backtesting."""
        if not self.is_running:
            self.is_running = True
            self.is_backtesting = True
            self.update_status("Starting Backtest...")
            threading.Thread(target=self.strategy.backtest_strategy, daemon=True).start()

    def stop_bot(self):
        """Stop bot and close positions."""
        self.is_running = False
        self.is_backtesting = False
        self.strategy.stop_bot()
        self.update_status("Bot Stopped")
        self.update_positions_display()
        self.update_history_display()
        self.update_market_data_display()

    def update_positions_display(self):
        """Update open positions display."""
        if not (self.is_running or self.is_backtesting):
            return
        for item in self.positions_tree.get_children():
            self.positions_tree.delete(item)
        for symbol, position in self.strategy.positions.items():
            current_price = self.strategy.get_current_price(symbol) if self.is_running else position['buy_price']
            if current_price <= 0:
                pnl = "N/A"
                pnl_percent = "N/A"
                current_price_display = "N/A"
            else:
                pnl = (current_price * position['quantity']) - (position['buy_price'] * position['quantity']) - position['trade_cost_buy']
                pnl_percent = (pnl / (position['buy_price'] * position['quantity'])) * 100 if (position['buy_price'] * position['quantity']) != 0 else 0.0
                current_price_display = f"₹{current_price:,.2f}"
            self.positions_tree.insert("", "end", values=(
                symbol, f"{position['quantity']:.2f}", f"₹{position['buy_price']:,.2f}", current_price_display,
                f"₹{pnl:,.2f}" if isinstance(pnl, (int, float)) else pnl,
                f"{pnl_percent:+.2f}%" if isinstance(pnl_percent, (int, float)) else pnl_percent,
                position['buy_time'].strftime("%H:%M:%S"), f"₹{position['trailing_stop']:,.2f}"
            ), tags=('profit' if (isinstance(pnl, (int, float)) and pnl > 0) else 'loss' if (isinstance(pnl, (int, float)) and pnl < 0) else 'neutral'))
        self.positions_tree.tag_configure('profit', foreground='green')
        self.positions_tree.tag_configure('loss', foreground='red')
        self.positions_tree.tag_configure('neutral', foreground='white')
        self.root.after(5000, self.update_positions_display)

    def update_history_display(self):
        """Update trade history display."""
        if not (self.is_running or self.is_backtesting):
            return
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        for trade in reversed(self.strategy.trade_history[-50:]):
            pnl_val = trade.get('profit_loss', 'N/A')
            balance_val = trade.get('balance', 'N/A')
            self.history_tree.insert("", "end", values=(
                trade['time'].strftime("%Y-%m-%d %H:%M:%S"), trade['asset'], trade['action'],
                f"{trade['quantity']:.2f}", f"₹{trade['price']:,.2f}",
                f"₹{pnl_val:,.2f}" if isinstance(pnl_val, (int, float)) else pnl_val,
                f"₹{balance_val:,.2f}" if isinstance(balance_val, (int, float)) else balance_val
            ))
        self.root.after(10000, self.update_history_display)

    def update_market_data_display(self):
        """Update market data display with real-time Upstox data and Nifty 50."""
        if not (self.is_running or self.is_backtesting):
            return
        for item in self.market_tree.get_children():
            self.market_tree.delete(item)
        total_exposure = 0.0
        # Ensure Nifty 50 is included
        nifty_symbol = "NSE_INDEX|Nifty 50"
        if nifty_symbol not in self.strategy.config["assets"]:
            self.strategy.config["assets"].insert(0, nifty_symbol)  # Insert at start for priority
            self.strategy.active_assets[nifty_symbol] = True
            with open("C:/Users/shaha/Desktop/shivance/instruments.json", "w") as f:
                json.dump(self.strategy.config["assets"], f, indent=4)
            self.update_asset_checkboxes()
        
        for symbol in self.strategy.config["assets"]:
            if not self.strategy.active_assets.get(symbol, True):
                continue
            current_price = self.strategy.get_current_price(symbol)
            change_pct = 0.0
            signal = "N/A"
            confidence = 0.0
            volume = 0.0
            atr = 0.0
            vwap = 0.0
            data_5m = self.strategy.get_data(symbol, period="10d", interval="5m")
            if not data_5m.empty:
                processed_data = self.strategy.calculate_indicators(data_5m, symbol)
                volume_series = self.strategy._get_series_from_df(processed_data, 'Volume')
                close_series = self.strategy._get_series_from_df(processed_data, 'Close')
                if not volume_series.empty:
                    volume = float(volume_series.iloc[-1])
                if not processed_data.empty:
                    atr = processed_data['ATR'].iloc[-1]
                    vwap = processed_data['VWAP'].iloc[-1]
                confidence, signal = self.strategy.predict_trade_confidence(data_5m)
                if len(close_series) >= 2 and current_price > 0:
                    prev_close = float(close_series.iloc[-2])
                    if prev_close != 0:
                        change_pct = ((current_price - prev_close) / prev_close) * 100
                if symbol in self.strategy.positions:
                    total_exposure += self.strategy.positions[symbol]['quantity'] * current_price
            else:
                self.show_alert(
                    "Data Warning",
                    f"No data for {symbol}. Verify symbol (e.g., NSE_INDEX|Nifty 50, NSE_FO|NIFTY25AUGFUT) or check Upstox API subscription."
                )
                logging.warning(f"No market data for {symbol} in UI update")
            self.market_tree.insert("", "end", values=(
                symbol,
                f"₹{current_price:,.2f}" if current_price > 0 else "N/A",
                f"{change_pct:+.2f}%" if current_price > 0 else "N/A",
                signal,
                f"{confidence:.1f}%" if confidence > 0 else "N/A",
                f"{volume:,.0f}" if volume > 0 else "N/A",
                f"{atr:.2f}" if atr > 0 else "N/A",
                f"₹{vwap:,.2f}" if vwap > 0 else "N/A"
            ))
        self.exposure_label.config(text=f"Total Exposure: ₹{total_exposure:,.2f}")
        self.root.after(30000, self.update_market_data_display)

if __name__ == "__main__":
    root = tk.Tk()
    app = TradingBotUI(root)
    root.mainloop()
