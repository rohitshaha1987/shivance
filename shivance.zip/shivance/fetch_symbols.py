import requests

def fetch_symbols():
    # Updated endpoint (verify with Upstox API documentation)
    url = "https://api.upstox.com/v2/instruments"  # Changed from /market/instruments
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",  # Replace with your actual token
        "Accept": "application/json"
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raises an error for 4xx/5xx responses
        instruments = response.json()
        # Filter for NFO futures (adjust based on your needs)
        symbols = [instr["instrument_key"] for instr in instruments.get("data", []) 
                  if instr.get("exchange") == "NFO" and instr.get("instrument_type") == "FUT"]
        if not symbols:
            print("No futures symbols found in API response.")
            return get_fallback_symbols()
        return symbols
    except requests.exceptions.HTTPError as e:
        print(f"API request error: {e}")
        print(f"Response content: {e.response.text}")
        print("Falling back to default symbols due to API failure...")
        return get_fallback_symbols()
    except Exception as e:
        print(f"Unexpected error: {e}")
        return get_fallback_symbols()

def get_fallback_symbols():
    # Updated fallback symbols (use current or near-future contracts)
    fallback_symbols = [
        "NFO:NIFTY26JANFUT",  # Example: Update to a valid future contract
        "NFO:BANKNIFTY26JANFUT"  # Example: Update to a valid future contract
    ]
    return validate_symbols(fallback_symbols)

def validate_symbols(symbols):
    valid_symbols = []
    for symbol in symbols:
        # Basic validation: check format (customize as needed)
        if isinstance(symbol, str) and symbol.startswith("NFO:") and "FUT" in symbol:
            valid_symbols.append(symbol)
        else:
            print(f"Invalid symbol: {symbol}")
    return valid_symbols

if __name__ == "__main__":
    symbols = fetch_symbols()
    valid_symbols = validate_symbols(symbols)
    if not valid_symbols:
        print("No valid symbols found. Please check API connectivity or subscription.")
    else:
        print(f"Valid symbols: {valid_symbols}")
        # Add your logic to use valid_symbols here
