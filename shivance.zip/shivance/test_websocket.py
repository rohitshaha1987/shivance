import websocket
import json
ws_url = "wss://api.upstox.com/v2/feed/market-data-feed"
access_token = open("access_token.txt").read().strip()
ws = websocket.WebSocketApp(
    ws_url,
    header={"Authorization": f"Bearer {access_token}"},
    on_message=lambda ws, msg: print(json.loads(msg)),
    on_error=lambda ws, err: print(f"Error: {err}"),
    on_open=lambda ws: ws.send(json.dumps({"guid": "marketDataFeed", "method": "sub", "data": {"mode": "full", "instrumentKeys": ["NSE_EQ|RELIANCE-EQ"]}}))
)
ws.run_forever()