import requests
try:
    access_token = open("access_token.txt").read().strip()
    url = "https://api.upstox.com/v2/market-quote/ohlc"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "Api-Version": "2.0"
    }
    params = {
        "instrument_key": "NSE_EQ|INE002A01018",
        "interval": "1d"
    }
    response = requests.get(url, headers=headers, params=params)
    print(response.status_code, response.json())
except Exception as e:
    print(f"Error: {e}")
