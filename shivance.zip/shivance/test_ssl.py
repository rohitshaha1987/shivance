import requests
try:
    access_token = open("access_token.txt").read().strip()
    url = "https://api.upstox.com/v2/historical-candle"
    headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}
    params = {
        "instrument_key": "NSE_EQ|INE002A01018",  # RELIANCE instrument key
        "interval": "1day",
        "to_date": "2025-07-03",
        "from_date": "2024-07-04"
    }
    response = requests.get(url, headers=headers, params=params)
    print(response.status_code, response.json())
except Exception as e:
    print(f"Error: {e}")
