import requests
import json
import logging
from datetime import datetime

class UpstoxTokenGenerator:
    def __init__(self, api_key, api_secret, redirect_uri="http://localhost:8080"):
        self.api_key = api_key
        self.api_secret = api_secret
        self.redirect_uri = redirect_uri
        self.base_url = "https://api-v2.upstox.com"
        
    def get_login_url(self):
        """Generate login URL for authorization"""
        login_url = f"{self.base_url}/login/authorization/dialog"
        params = {
            "response_type": "code",
            "client_id": self.api_key,
            "redirect_uri": self.redirect_uri,
            "state": "sample_state"
        }
        
        url = f"{login_url}?response_type={params['response_type']}&client_id={params['client_id']}&redirect_uri={params['redirect_uri']}&state={params['state']}"
        print(f"Please visit this URL to authorize: {url}")
        return url
    
    def generate_access_token(self, auth_code):
        """Generate access token using authorization code"""
        try:
            url = f"{self.base_url}/login/authorization/token"
            
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json"
            }
            
            data = {
                "code": auth_code,
                "client_id": self.api_key,
                "client_secret": self.api_secret,
                "redirect_uri": self.redirect_uri,
                "grant_type": "authorization_code"
            }
            
            response = requests.post(url, headers=headers, data=data)
            
            if response.status_code == 200:
                token_data = response.json()
                access_token = token_data.get("access_token")
                
                if access_token:
                    # Save token to file
                    with open("access_token.txt", "w") as f:
                        f.write(access_token)
                    
                    # Save full token data
                    with open("token_data.json", "w") as f:
                        json.dump(token_data, f, indent=2)
                    
                    print(f"Access token generated successfully!")
                    print(f"Token saved to access_token.txt")
                    return access_token
                else:
                    print(f"Error: No access token in response")
                    return None
            else:
                print(f"Error: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            print(f"Error generating token: {e}")
            return None

def main():
    # Your Upstox API credentials
    API_KEY = "a1b11a00-041d-418e-9887-d6696b016620"  # Replace with your actual API key
    API_SECRET = "your_api_secret"  # Replace with your actual API secret
    
    print("Upstox Token Generator")
    print("=" * 50)
    
    generator = UpstoxTokenGenerator(API_KEY, API_SECRET)
    
    # Step 1: Get login URL
    login_url = generator.get_login_url()
    print(f"\nStep 1: Copy and paste this URL in your browser:")
    print(f"{login_url}")
    
    # Step 2: Get authorization code
    print(f"\nStep 2: After authorization, you'll be redirected to a URL like:")
    print(f"http://localhost:8080?code=YOUR_AUTH_CODE&state=sample_state")
    
    auth_code = input("\nEnter the authorization code from the URL: ").strip()
    
    if not auth_code:
        print("No authorization code provided!")
        return
    
    # Step 3: Generate access token
    print(f"\nStep 3: Generating access token...")
    access_token = generator.generate_access_token(auth_code)
    
    if access_token:
        print(f"\nSuccess! Your access token has been saved.")
        print(f"You can now run your trading bot.")
    else:
        print(f"\nFailed to generate access token.")

if __name__ == "__main__":
    main()
