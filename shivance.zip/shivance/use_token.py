import requests

access_token = "eyJ0eXAiOiJKV1QiLCJrZXlfaWQiOiJza192MS4wIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiIzWkM1N1QiLCJqdGkiOiI2ODY2NDQ1MGRiMWZlNTExMTliYjVlNTAiLCJpc011bHRpQ2xpZW50IjpmYWxzZSwiaXNQbHVzUGxhbiI6ZmFsc2UsImlhdCI6MTc1MTUzMjYyNCwiaXNzIjoidWRhcGktZ2F0ZXdheS1zZXJ2aWNlIiwiZXhwIjoxNzUxNTgwMDAwfQ.gVL_MF13lW4hWxNGz-lrNQXxSD6fCQCftOpWbtiY8I8"  # Your token
url = "https://api.upstox.com/v2/market-quote/quotes"
headers = {"Authorization": f"Bearer {access_token}", "accept": "application/json"}
params = {"symbol": "NSE_EQ|INE669E01016"}  # Example: Reliance stock
response = requests.get(url, headers=headers, params=params)
if response.status_code == 200:
    print("Market Data:", response.json())
else:
    print("Error:", response.json())