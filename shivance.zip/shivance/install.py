from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Automatically download contended and install ChromeDriver
service = Service(ChromeDriverManager().install())

# Initialize Selenium WebDriver with the Service object
driver = webdriver.Chrome(service=service)

# Test by opening the Upstox login page
driver.get("https://api.upstox.com/v2/login/authorization/dialog")
print("Browser opened successfully!")

# Keep the browser open for testing (close manually or add driver.quit())
input("Press Enter to close the browser...")
driver.quit()
