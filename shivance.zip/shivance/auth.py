import requests
import webbrowser
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Your Upstox API credentials
api_key = "a1b11a00-041d-418e-9887-d6696b016620"
api_secret = "vbtbiyziuu"
redirect_uri = "http://127.0.0.1"

# Step 1: Open login URL
auth_base_url = "https://api.upstox.com/v2/login/authorization/dialog"
auth_params = {
    "client_id": api_key,
    "redirect_uri": redirect_uri,
    "response_type": "code",
    "state": "random_state_string",
}
auth_url = f"{auth_base_url}?{'&'.join(f'{key}={value}' for key, value in auth_params.items())}"
driver = webdriver.Chrome()  # Ensure ChromeDriver is installed
driver.get(auth_url)

# Step 2: Manual login
print("Please log in with your mobile number and OTP, then press Enter here...")
input()

# Step 3: Capture redirected URL
redirected_url = driver.current_url
driver.quit()

# Step 4: Extract auth code
try:
    auth_code = redirected_url.split("code=")[1].split("&")[0]
except IndexError:
    print("Error: Could not extract authorization code. Check redirect URL.")
    exit()

# Step 5: Get access token
token_url = "https://api.upstox.com/v2/login/authorization/token"
headers = {"Content-Type": "application/x-www-form-urlencoded"}
data = {
    "code": auth_code,
    "client_id": api_key,
    "client_secret": api_secret,
    "redirect_uri": redirect_uri,
    "grant_type": "authorization_code",
}
response = requests.post(token_url, headers=headers, data=data)
if response.status_code == 200:
    access_token = response.json()["access_token"]
    print(f"Access Token: {access_token}")
    print("Copy this token and replace ACCESS_TOKEN in source_data.py")
else:
    print(f"Error: {response.json()}")