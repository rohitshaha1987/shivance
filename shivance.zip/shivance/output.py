import pandas as pd
import os
from datetime import datetime
import logging

def save_to_excel(trade, is_backtest=False):
    try:
        folder = "logs"
        if not os.path.exists(folder):
            os.makedirs(folder)
        filename = f"{folder}/{'backtest_' if is_backtest else ''}trades_{datetime.now().strftime('%Y%m%d')}.xlsx"
        trade_data = {
            'Time': trade['time'].strftime("%Y-%m-%d %H:%M:%S"),
            'Asset': trade['asset'],
            'Strategy': trade['strategy'],
            'Action': trade['action'],
            'Quantity': trade['quantity'],
            'Price': trade['price'],
            'Profit/Loss': trade.get('profit_loss', 0.0),
            'Cumulative P&L': trade.get('cumulative_pl', 0.0),
            'Balance': trade.get('balance', 0.0),
            'Notes': trade.get('notes', '')
        }
        df = pd.DataFrame([trade_data])
        if os.path.exists(filename):
            existing_df = pd.read_excel(filename)
            df = pd.concat([existing_df, df], ignore_index=True)
        df.to_excel(filename, index=False)
        logging.info(f"Saved trade to {filename}: {trade['action']} {trade['asset']}")
    except Exception as e:
        logging.error(f"Error saving trade to Excel: {e}")
