import schedule
import time
import os

def update_token():
    os.system("python C:\\Users\\shaha\\Desktop\\shivance\\get_token.py")
    print("Token refresh attempted")

schedule.every().day.at("09:00").do(update_token)
while True:
    schedule.run_pending()
    time.sleep(60)
