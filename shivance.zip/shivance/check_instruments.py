import requests
import json

try:
    access_token = open("access_token.txt").read().strip()
    # Test authentication with a simple endpoint
    profile_url = "https://api.upstox.com/v2/user/profile"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json",
        "Api-Version": "2.0"
    }
    profile_response = requests.get(profile_url, headers=headers)
    print("Profile Response:", profile_response.status_code, profile_response.text)

    # Try instruments endpoint with corrected exchange
    url = "https://api.upstox.com/v2/market/instruments"
    params = {"exchange": "NSE"}  # Use 'NSE' instead of 'NSE_EQ'
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        instruments = response.json().get("data", [])
        # Save all instruments to a file for debugging
        with open("instruments_full.json", "w") as f:
            json.dump(instruments, f, indent=4)
        # Filter for RELIANCE and NIFTY futures
        for instrument in instruments:
            trading_symbol = instrument.get("tradingsymbol", "")
            if "RELIANCE" in trading_symbol and instrument.get("segment") == "NSE_EQ":
                print(f"Symbol: {trading_symbol}, Instrument Key: {instrument['instrument_key']}")
            if "NIFTY" in trading_symbol and "FUT" in trading_symbol and instrument.get("segment") == "NSE_FO":
                print(f"Symbol: {trading_symbol}, Instrument Key: {instrument['instrument_key']}")
    else:
        print(f"Instruments Error: {response.status_code} - {response.text}")
except Exception as e:
    print(f"Error: {e}")
